CONFIG = {
    RULES = {
        --"Rule number 1",
        --"Rule number 2",
        --"Rule number 3",
        --"Rule number 4",
        --"Rule number 5",
    },
}
